import os, sys
path_name= os.path.dirname(os.path.abspath(os.path.dirname(os.path.abspath(os.path.dirname(__file__)))))
sys.path.append(path_name)

from _element import varr
from _element import feature_control as ft_c
from _element import calculations
from _usecase import *
from datetime import datetime, timedelta

def AlgorithmCompare(testY, algorithm):
    global mockForecastDictionary
    nameOfBestAlgorithm = 'LSTM'
    minData = calculation.rms_error(testY, mockForecastDictionary[nameOfBestAlgorithm])
    rms = 0
    for algorithm in mockForecastDictionary.keys():
        rms = calculation.rms_error(testY, mockForecastDictionary[algorithm])
        if rms < minData:
            nameOfBestAlgorithm = algorithm
    print('testY is: ', testY)
    print('\n')
    print('LSTM forecast :', mockForecastDictionary['LSTM'], '\n@@@@@LSTM calculation.rms_error: ',
          calculation.rms_error(testY, mockForecastDictionary['LSTM']))
    print('Bayseian forecast :', mockForecastDictionary['Bayseian'], '\n@@@@@Bayseian calculation.rms_error: ',
          calculation.rms_error(testY, mockForecastDictionary['Bayseian']))
    print('\n')
    print(nameOfBestAlgorithm, 'WON!!!!!!')
    return nameOfBestAlgorithm

class Cross_Validation:
    def __init__(self):
        self.cv_data= None

    def slice(self, df, y, x_col, forecastday= varr.FORECASTDAY, num_of_data= 5, delay= 70, recent= True):
        test_end_date= varr.LAST_DATE
        cv_dict= {}
        for i in range(num_of_data):
            cv_dict[i]= ft_c.train_test_sample(df[(df['ds']<= test_end_date)],
                                                y,
                                                x_col,
                                                forecastday= forecastday
                                                )
            test_end_date= test_end_date- timedelta(days= delay)
        self.cv_data= cv_dict

    def func_run(self, func, extract_func, output= 'info', **kwargs):
        dict_option= kwargs
        if 'forecastday' in dict_option.keys():
            forecastday= dict_option['forecastday']
        else:
            forecastday= varr.FORECASTDAY

        alg_result_dict= {}
        alg_info_dict= {}
        if self.cv_data:
            for i, df_cv in self.cv_data.items():
                alg_result_dict[i]= func(df_cv, **dict_option)
                alg_info_dict[i]= extract_func(
                                                alg_result_dict[i]['future'],
                                                alg_result_dict[i]['forecastProphetTable'],
                                                forecastday
                                                )
        if output== 'info':
            return alg_info_dict
        elif output== 'result':
            return alg_result_dict
        elif output== 'sMAPE':
            for i, info_dict in alg_info_dict.items():
                print(info_dict['result_df'].head())
                print('sMAPE of cv case {}: '.format(i),
                        str(calculations.smap_error(self.cv_data[i]['testY'], info_dict['result_df']['yhat']))
                        )
            return None